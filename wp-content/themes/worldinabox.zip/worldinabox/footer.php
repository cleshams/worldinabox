

            <div>
                <div class="content__item--lg">
                    <h3 class="page-header"><i class="fa fa-instagram" aria-hidden="true"></i>&nbsp;<a href="https://www.instagram.com/worldinaboxmovema/" target="_blank">#worldinaboxmovema</a></h3>
                    <?php echo do_shortcode('[instagram-feed]'); ?>
                </div>
            </div>

        </main>

        <footer class="site-footer">
            <div class="container container--inner">
                <div class="columns">
                    <div class="columns__column columns__column--half">

                        <div class="content__item">
                            <img src="<?php echo THEME_URI; ?>/assets/images/logo.svg" class="site-logo__img footer-logo__img">
                        </div>

                        <div class="content__item">
                            <h4 class="h3">Sign up to our newsletter</h4>
                            <p>To get regular news, fun updates, latest videos and lesson plans sign up to our newsletter!</p>
                            <form action="https://purearth.us7.list-manage.com/subscribe/post?u=7c60d8fb539768d32e160c3b9&amp;id=65530785ff" method="post" id="mc-embedded-subscribe-form" name="mailchimp__form" class="mailchimp__form validate" target="_blank" novalidate>
                                <div class="form__group">
                                    <input class="required email mailchimp__email form__group-input" type="email" value="" name="EMAIL" id="mce-EMAIL" placeholder="Enter email">
                                    <input value="Sign up" class="btn mailchimp__btn form__group-input form__group-btn" type="submit" name="subscribe" id="mc-embedded-subscribe" >
                                </div>
                            </form>
                        </div>

                        <div class="content__item">
                            <h5>Follow us</h5>
                            <?php
                              wp_nav_menu(
                                  array(
                                      'theme_location'  => 'social-media',
                                      'link_before'     => '<span class="screen-reader-text">',
                                      'link_after'      => '</span>',
                                      'depth'           => 1,
                                      'fallback_cb'     => '',
                                  )
                              );
                            ?>
                        </div>

                        <div class="content__item">
                            <nav class="nav">
                                <?php
                                   wp_nav_menu([
                                     'menu'            => 'main-menu',
                                     'theme_location'  => 'primary-menu',
                                     'container'       => '',
                                     'container_id'    => 'bs4navbar',
                                     'container_class' => '',
                                     'menu_id'         => false,
                                     // 'menu_class'      => 'nav__menu',
                                     'depth'           => 2,
                                     'fallback_cb'     => 'bs4navwalker::fallback',
                                     'walker'          => new bs4navwalker()
                                   ]);
                                ?>
                            </nav>

                    		<p class="site-footer__copy">&copy; <?php echo date( 'Y' ); ?> <?php bloginfo( 'name' ); ?> | <a href="">Privacy Policy</a></p>
                    	</div>

                    </div>
                </div>

            </div>
        </footer>
	   <?php wp_footer(); ?>
	</body>
</html>
