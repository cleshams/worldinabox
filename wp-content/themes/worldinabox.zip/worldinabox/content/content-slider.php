<div class="owl-carousel">
  <div class="item" data-videosrc="http://vpmdev.com/window.mp4">
    <img src='//placehold.it/800x600.png'/>
    <div class='promo-container'>
      <div class='promo'>
        <h2>Promo Title Here</h2>
        <a href="#" class="btn btn-default">Watch Video</a>
        <a href="#" class="btn btn-default">Learn More</a>
      </div>
    </div>
  </div>
  <div class="item">
    <img src='//placehold.it/800x600.png'/>
    <div class='promo-container'>
      <div class='promo'>
        <h2>Promo Title Here</h2>
        <a href="#" class="btn btn-default">Watch Video</a>
        <a href="#" class="btn btn-default">Learn More</a>
      </div>
    </div>
  </div>
  <div class="item" data-videosrc="http://vpmdev.com/window.mp4">
    <img src='//placehold.it/800x600.png'/>
    <div class='promo-container'>
      <div class='promo'>
        <h2>Promo Title Here</h2>
        <a href="#" class="btn btn-default">Watch Video</a>
        <a href="#" class="btn btn-default">Learn More</a>
      </div>
    </div>
  </div>
  <div class="item" data-videosrc="http://vpmdev.com/window.mp4">
    <img src='//placehold.it/800x600.png'/>
    <div class='promo-container'>
      <div class='promo'>
        <h2>Promo Title Here</h2>
        <a href="#" class="btn btn-default">Watch Video</a>
        <a href="#" class="btn btn-default">Learn More</a>
      </div>
    </div>
  </div>
  <div class="item">
    <img src='//placehold.it/800x600.png'/>
    <div class='promo-container'>
      <div class='promo'>
        <h2>Promo Title Here</h2>
        <a href="#" class="btn btn-default">Watch Video</a>
        <a href="#" class="btn btn-default">Learn More</a>
      </div>
    </div>
  </div>
</div>
