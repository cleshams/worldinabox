    <div class="hero home-hero">
        <div class="hero__overlay"></div>

        <div class="hero__content--abs">
            <div class="hero__content-inner">          
                <div class="container container--inner">
                    <div class="columns hero__columns">
                        <div class="columns__column columns__column--half">
                            <h1 class="hero__title">Easy &amp; fun <span>world dance resources</span></h1>
                                <p class="hero__text">"World in a Box has all the resources you need in one box. It’s fun, cross-curricular, adaptable and creative!"</p>
                                <p class="hero__text hero__text--small">- Debbie Woods, Primary School Teacher</p>
                                <a href="" class="btn btn--primary hero__btn">Get World in a Box</a>
                        </div>
                        <div class="columns__column columns__column--half hero-btn-video">
                            <a href="http://www.youtube.com/watch?v=_xJSTLJtEyE&t=15s" class="hero-btn-video__btn mp-iframe">
                                <i class="fa fa-play-circle" aria-hidden="true"></i>
                                <span>Play video</span>
                            </a>
                        </div>

                    </div><!-- /End Row -->
                </div><!-- /End Container -->
            </div>
        </div>

        <div class="bg-video video-play"
        data-vide-bg="mp4: <?php echo THEME_URI; ?>/assets/video/wiab-video, webm: <?php echo THEME_URI; ?>/assets/video/wiab-video, ogv: <?php echo THEME_URI; ?>/assets/video/wiab-video, poster: <?php echo THEME_URI; ?>/assets/video/wiab-video"
        data-vide-options="posterType: jpg, loop: true, muted: true, position: 0% 0%">
        </div>  

    </div>
