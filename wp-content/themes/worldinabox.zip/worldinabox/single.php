<?php get_header() ; ?>



	<?php if ( have_posts() ): ?>

	<?php while ( have_posts() ) : the_post(); ?>

    <section>
        <div class="content main-content">
            <div class="container container--inner">

                <article>
                    <h2><?php the_title(); ?></h2>

                    <?php the_content(); ?>

                </article>


            </div>
        </div>
    </section>



    <?php endwhile; ?>


    <?php else: ?>
    <h4>No posts to display</h4>
    <?php endif; ?>




<?php get_footer(); ?>
