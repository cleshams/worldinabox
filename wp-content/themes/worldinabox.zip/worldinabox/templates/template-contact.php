<?php
/**
*   Template name: Contact
**/
?>

<?php get_header() ; ?>


	<?php if ( have_posts() ): ?>

	<?php while ( have_posts() ) : the_post(); ?>





<section>
    <div class="content main-content">
        <div class="container container--inner">

   <!-- =========================
         MAP
    ============================== -->
        <div id="map" style="height: 480px"></div>
        <script>
        function initMap() {
            var myLatLng = {lat: 52.241627, lng: 0.775224};

            var drgflag=true;

            var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 16,
            center: myLatLng,
            scrollwheel: false,
            draggable:drgflag,
            });

            var image = {
                url: '<?php echo THEME_URI; ?>/assets/images/map-icon.svg',
                scaledSize: new google.maps.Size(35, 55)
            }

            var marker = new google.maps.Marker({
            position: myLatLng,
            map: map,
            title: 'Hello World!',
            icon: image
            });

            var styles = [{
                stylers: [{
                    hue: "#8a8a8a"
                }, {
                    saturation: -90
                }]
            }, {
                featureType: "road",
                elementType: "geometry",
                stylers: [{
                    lightness: 100
                }, {
                    visibility: "simplified"
                }]
            }, {
                featureType: "road",
                elementType: "labels",
                stylers: [{
                    visibility: "on"
                }]
            }];

            map.setOptions({
                styles: styles
            });


        }

        </script>
    <!-- /* Map section */ -->



            <div class="content__item">
                <div class="columns">
                    <div class="columns__column columns__column--half">
                        <?php echo do_shortcode('[contact-form-7 id="27" title="Contact form 1"]'); ?>
                    </div>
                    <div class="columns__column columns__column--half">
                        <?php if (get_post_meta( $post->ID, '_cm_contact_address', true )) {
                            echo wpautop(get_post_meta( $post->ID, '_cm_contact_address', true ));
                        } ?>

                        <?php if (get_post_meta( $post->ID, '_cm_contact_office_phone', true )) {
                            echo '<div class="contact__phone">';
                            echo '<p>Office:</p>';
                            echo '<p>' . get_post_meta( $post->ID, '_cm_contact_office_phone', true ) . '</p>';
                            echo '</div>';
                        } ?>

                        <?php if (get_post_meta( $post->ID, '_cm_contact_mobile_phone', true )) {
                            echo '<div class="contact__phone">';
                            echo '<p>Mobile:</p>';
                            echo '<p>' . get_post_meta( $post->ID, '_cm_contact_mobile_phone', true ) . '</p>';
                            echo '</div>';
                        } ?>

                        <div class="content__item">
                        <?php
                            wp_nav_menu(
                                array(
                                    'theme_location'  => 'social-media',
                                    'link_before'     => '<span class="screen-reader-text">',
                                    'link_after'      => '</span>',
                                    'depth'           => 1,
                                    'fallback_cb'     => '',
                                )
                            );
                        ?>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>
</section>






	<?php endwhile; endif; ?>

<?php get_footer(); ?>
